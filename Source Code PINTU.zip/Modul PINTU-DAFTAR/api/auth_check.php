<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header("Location: ../index.html");
    exit;
}

function pastikanSuperAdmin() {
    if ($_SESSION['admin_level'] !== 'admin') {
        echo "<div style='font-family:sans-serif; text-align:center; padding:50px;'>
                <h2 style='color:#e11d48;'>Akses Ditolak!</h2>
                <p>Halaman ini hanya dapat diakses oleh Administrator level utama.</p>
                <a href='index.php'>Kembali ke Dashboard</a>
              </div>";
        exit;
    }
}