<?php

if (!function_exists('catatLog')) {
    function catatLog($pdo, $aktivitas, $kategori = 'UMUM') {
        try {
            $actor = 'Sistem / Publik';
            
            if (isset($_SESSION['admin_nama'])) {
                $nama  = $_SESSION['admin_nama'];
                $level = strtoupper($_SESSION['admin_level'] ?? 'ADMIN');
                $lembaga = isset($_SESSION['admin_lembaga']) && !empty($_SESSION['admin_lembaga']) ? ' - ' . $_SESSION['admin_lembaga'] : '';
                $actor = "{$nama} ({$level}{$lembaga})";
            } elseif (isset($_SESSION['cpmi_id'])) {
                $actor = 'Peserta CPMI ID: ' . $_SESSION['cpmi_id'];
            }

            $ipAddress = '0.0.0.0';
            if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
                $ipAddress = $_SERVER['HTTP_CF_CONNECTING_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
                $ipAddress = trim($ipList[0]);
            } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
                $ipAddress = $_SERVER['HTTP_X_REAL_IP'];
            } else {
                $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
            }

            $stmtLog = $pdo->prepare("
                INSERT INTO tb_log (actor, kategori, aktivitas, ip_address) 
                VALUES (?, ?, ?, ?)
            ");
            $stmtLog->execute([$actor, strtoupper($kategori), $aktivitas, $ipAddress]);

        } catch (Throwable $e) {
        }
    }
}