<?php
ob_start();
session_start();

if (file_exists(__DIR__ . '/../config.php')) {
    require_once __DIR__ . '/../config.php';
} elseif (file_exists(__DIR__ . '/config.php')) {
    require_once __DIR__ . '/config.php';
} else {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'error', 'pesan' => 'Konfigurasi peladen tidak ditemukan.']);
    exit;
}

if (ob_get_length()) {
    ob_clean();
}
header('Content-Type: application/json; charset=utf-8');

$inputRaw = file_get_contents('php://input');
$dataJson = json_decode($inputRaw, true);
$nik = trim($_POST['nik'] ?? $dataJson['nik'] ?? '');

if (strlen($nik) !== 16 || !ctype_digit($nik)) {
    echo json_encode(['status' => 'error', 'pesan' => 'Format NIK tidak valid. Harap masukkan tepat 16 digit angka.']);
    exit;
}

try {
    $isPemutihan = false;
    try {
        $stmtPem = $pdo->prepare("SELECT COUNT(*) FROM tb_master_pemutihan WHERE nik = ? AND status_aktif = 'Y'");
        $stmtPem->execute([$nik]);
        if ($stmtPem->fetchColumn() > 0) {
            $isPemutihan = true;
        }
    } catch (Throwable $e) {}

    if (!$isPemutihan) {
        $stmtLolos = $pdo->prepare("
            SELECT p.cpmi_id, p.nama_lengkap, p.batch_pelatihan, v.status
            FROM tb_pendaftaran p
            JOIN tb_status_verifikasi v ON p.cpmi_id = v.cpmi_id
            WHERE p.nik_sesuai_ktp = ?
              AND UPPER(TRIM(v.status)) = 'MEMENUHI PERSYARATAN'
            ORDER BY p.cpmi_id DESC
            LIMIT 1
        ");
        $stmtLolos->execute([$nik]);
        $dataLolos = $stmtLolos->fetch(PDO::FETCH_ASSOC);

        if ($dataLolos) {
            echo json_encode([
                'status' => 'error',
                'pesan'  => "NIK sudah pernah terdaftar atas nama “{$dataLolos['nama_lengkap']}” (ID: {$dataLolos['cpmi_id']}) pada gelombang sebelumnya, anda tidak dapat mendaftar kembali."
            ]);
            exit;
        }
    }

    echo json_encode(['status' => 'success', 'pesan' => 'NIK valid dan memenuhi syarat untuk mendaftar.']);
} catch (Throwable $e) {
    echo json_encode(['status' => 'error', 'pesan' => 'Kesalahan basis data: ' . $e->getMessage()]);
}
exit;