<?php
session_start();

if (file_exists(__DIR__ . '/../config.php')) {
    require_once __DIR__ . '/../config.php';
} elseif (file_exists(__DIR__ . '/config.php')) {
    require_once __DIR__ . '/config.php';
} else {
    die('Berkas config.php tidak ditemukan.');
}

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

if (file_exists(__DIR__ . '/../api/helper_log.php')) {
    require_once __DIR__ . '/../api/helper_log.php';
    if (function_exists('catatLog')) {
        catatLog($pdo, "Mengakses Halaman Dashboard Eksekutif PINTU", 'DASHBOARD');
    }
}

$namaAdmin    =$_SESSION['admin_nama'] ?? 'Admin';
$levelAdmin   =$_SESSION['admin_level'] ?? 'user';
$isSuperAdmin = in_array(strtolower($levelAdmin), ['superadmin', 'admin']);

register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && ($error['type'] === E_ERROR || $error['type'] === E_PARSE OR$error['type'] === E_CORE_ERROR)) {
        echo "<div style='padding:20px; background:#fee2e2; color:#991b1b; font-family:sans-serif; margin:20px; border-radius:10px;'>";
        echo "<h3>Terjadi Kesalahan Fatal PHP:</h3>";
        echo "<p><b>Pesan:</b> " . htmlspecialchars($error['message']) . "</p>";
        echo "<p><b>Berkas:</b> " . htmlspecialchars($error['file']) . " (Baris " . $error['line'] . ")</p>";
        echo "</div>";
    }
});

$selectedBatch = trim($_GET['batch'] ?? 'all');

$listBatch = [];
try {
    $stmtBatch =$pdo->query("
        SELECT DISTINCT batch_pelatihan 
        FROM tb_pendaftaran 
        WHERE batch_pelatihan IS NOT NULL AND batch_pelatihan != '' 
        ORDER BY batch_pelatihan ASC
    ");
    $listBatch =$stmtBatch->fetchAll(PDO::FETCH_COLUMN);

    if (empty($listBatch)) {
        $stmtPeriode =$pdo->query("SELECT nama_periode FROM tb_periode_gelombang ORDER BY id_periode ASC");
        $listBatch =$stmtPeriode->fetchAll(PDO::FETCH_COLUMN);
    }
} catch (Throwable $e) {$listBatch = [];
}

$whereP = "1=1";
$paramsP = [];
if ($selectedBatch !== 'all' && !empty($selectedBatch)) {
    $whereP .= " AND p.batch_pelatihan = ?";
    $paramsP = [$selectedBatch];
}

$totPendaftar     = 0;
$mayUsia          = '-';
$mayGender        = '-';

$totVerifMS       = 0;
$totVerifTMS      = 0;
$totVerifBelum    = 0;

$totNikGanda      = 0;
$pesertaTertulis  = 0;
$pesertaInterview = 0;
$avgTertulis      = 0.0;
$avgInterview     = 0.0;
$pelatihanPopuler = 'Belum ada data pendaftar';

$trendTanggal     = [];
$trendJumlah      = [];
$listTopLPK       = [];

$labelDaerah = [];
$dataDaerah  = [];
$labelMinat  = [];
$dataMinat   = [];

try {
    $sqlTot = "SELECT COUNT(*) FROM tb_pendaftaran p WHERE {$whereP}";
    $stmt = $pdo->prepare($sqlTot);
    $stmt->execute($paramsP);
    $totPendaftar = (int)$stmt->fetchColumn();
} catch (Throwable $e) {}

if ($totPendaftar > 0) {
    try {
        $sqlUsia = "SELECT usia FROM tb_pendaftaran p WHERE {$whereP} AND usia IS NOT NULL AND usia > 0 GROUP BY usia ORDER BY COUNT(*) DESC LIMIT 1";
        $stmt = $pdo->prepare($sqlUsia);
        $stmt->execute($paramsP);
        $mayUsia =$stmt->fetchColumn() ?: '-';
    } catch (Throwable $e) {}

    try {
        $sqlGender = "SELECT jenis_kelamin FROM tb_pendaftaran p WHERE {$whereP} AND jenis_kelamin IS NOT NULL AND jenis_kelamin != '' GROUP BY jenis_kelamin ORDER BY COUNT(*) DESC LIMIT 1";
        $stmt = $pdo->prepare($sqlGender);
        $stmt->execute($paramsP);
        $mayGender =$stmt->fetchColumn() ?: '-';
    } catch (Throwable $e) {}
    
    try {
        $sqlVerif = "
            SELECT 
                SUM(CASE WHEN UPPER(TRIM(v.status)) = 'MEMENUHI PERSYARATAN' THEN 1 ELSE 0 END) as ms,
                SUM(CASE WHEN UPPER(TRIM(v.status)) = 'TIDAK MEMENUHI PERSYARATAN' THEN 1 ELSE 0 END) as tms,
                SUM(CASE WHEN UPPER(TRIM(v.status)) NOT IN ('MEMENUHI PERSYARATAN', 'TIDAK MEMENUHI PERSYARATAN') OR v.status IS NULL THEN 1 ELSE 0 END) as belum
            FROM tb_pendaftaran p
            LEFT JOIN tb_status_verifikasi v ON p.cpmi_id = v.cpmi_id
            WHERE {$whereP}
        ";
        $stmtV =$pdo->prepare($sqlVerif);
        $stmtV->execute($paramsP);
        $rowV = $stmtV->fetch(PDO::FETCH_ASSOC);
        $totVerifMS    = (int)($rowV['ms'] ?? 0);
        $totVerifTMS   = (int)($rowV['tms'] ?? 0);
        $totVerifBelum = (int)($rowV['belum'] ?? 0);
    } catch (Throwable$e) {}
    
    try {
        $sqlNik = "SELECT COUNT(*) FROM (SELECT nik_sesuai_ktp FROM tb_pendaftaran p WHERE {$whereP} AND nik_sesuai_ktp IS NOT NULL AND nik_sesuai_ktp != '' GROUP BY nik_sesuai_ktp HAVING COUNT(*) > 1) AS sub_nik";
        $stmt = $pdo->prepare($sqlNik);
        $stmt->execute($paramsP);
        $totNikGanda = (int)$stmt->fetchColumn();
    } catch (Throwable $e) {}
    
    try {
        $sqlT = "SELECT COUNT(*) FROM tb_pendaftaran p WHERE {$whereP} AND LOWER(TRIM(status_tertulis)) = 'selesai'";
        $stmt = $pdo->prepare($sqlT);
        $stmt->execute($paramsP);
        $pesertaTertulis = (int)$stmt->fetchColumn();

        $sqlI = "SELECT COUNT(*) FROM tb_pendaftaran p WHERE {$whereP} AND LOWER(TRIM(status_interview)) = 'selesai'";
        $stmt = $pdo->prepare($sqlI);
        $stmt->execute($paramsP);
        $pesertaInterview = (int)$stmt->fetchColumn();
    } catch (Throwable $e) {}

    try {
        $sqlAvgT = "
            SELECT COALESCE(AVG(sub.benar_tertulis), 0) 
            FROM (
                SELECT j.cpmi_id, COUNT(*) AS benar_tertulis 
                FROM tb_jawaban_peserta j 
                JOIN tb_soal s ON j.soal_id = s.id 
                JOIN tb_pendaftaran p ON j.cpmi_id = p.cpmi_id
                WHERE s.jenis_ujian = 'tertulis' 
                  AND UPPER(TRIM(j.jawaban_pilihan)) = UPPER(TRIM(s.kunci))
        ";
        if ($selectedBatch !== 'all' && !empty($selectedBatch)) {$sqlAvgT .= " AND p.batch_pelatihan = ? GROUP BY j.cpmi_id) AS sub";
            $stmt = $pdo->prepare($sqlAvgT);
            $stmt->execute([$selectedBatch]);
        } else {
            $sqlAvgT .= " GROUP BY j.cpmi_id) AS sub";
            $stmt = $pdo->query($sqlAvgT);
        }
        $avgTertulis = (float)$stmt->fetchColumn();
    } catch (Throwable $e) {}

    try {
        $sqlAvgI = "
            SELECT COALESCE(AVG(sub.skor_interview), 0) 
            FROM (
                SELECT j.cpmi_id, SUM(CASE UPPER(TRIM(j.jawaban_pilihan)) WHEN 'A' THEN s.poin_a WHEN 'B' THEN s.poin_b WHEN 'C' THEN s.poin_c WHEN 'D' THEN s.poin_d ELSE 0 END) AS skor_interview 
                FROM tb_jawaban_peserta j 
                JOIN tb_soal s ON j.soal_id = s.id 
                JOIN tb_pendaftaran p ON j.cpmi_id = p.cpmi_id
                WHERE s.jenis_ujian = 'interview'
        ";
        if ($selectedBatch !== 'all' && !empty($selectedBatch)) {$sqlAvgI .= " AND p.batch_pelatihan = ? GROUP BY j.cpmi_id) AS sub";
            $stmt = $pdo->prepare($sqlAvgI);
            $stmt->execute([$selectedBatch]);
        } else {
            $sqlAvgI .= " GROUP BY j.cpmi_id) AS sub";
            $stmt = $pdo->query($sqlAvgI);
        }
        $avgInterview = (float)$stmt->fetchColumn();
    } catch (Throwable $e) {}

    try {
        $sqlPop = "
            SELECT TRIM(ref_pelatihan_dimin) AS nama_kategori, COUNT(*) AS jml 
            FROM tb_pendaftaran p
            WHERE {$whereP} 
              AND ref_pelatihan_dimin IS NOT NULL 
              AND TRIM(ref_pelatihan_dimin) != ''
            GROUP BY TRIM(ref_pelatihan_dimin)
            ORDER BY jml DESC LIMIT 1
        ";
        $stmt = $pdo->prepare($sqlPop);
        $stmt->execute($paramsP);
        $pelatihanPopuler =$stmt->fetchColumn() ?: 'Belum ada data';
    } catch (Throwable $e) {}

    try {
        $sqlTop5LPK = "
            SELECT TRIM(lembaga_pelatihan) AS nama_lembaga, COUNT(*) AS total 
            FROM tb_pendaftaran p
            WHERE {$whereP} 
              AND lembaga_pelatihan IS NOT NULL 
              AND TRIM(lembaga_pelatihan) != ''
            GROUP BY TRIM(lembaga_pelatihan)
            ORDER BY total DESC LIMIT 5
        ";
        $stmt = $pdo->prepare($sqlTop5LPK);
        $stmt->execute($paramsP);
        $listTopLPK = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {}

    try {
        $sqlTrend = "
            SELECT DATE(b_time.waktu_awal) as tgl, COUNT(DISTINCT p.cpmi_id) as jml 
            FROM tb_pendaftaran p
            LEFT JOIN tb_status_verifikasi sv ON p.cpmi_id = sv.cpmi_id
            INNER JOIN (
                SELECT cpmi_id, MIN(uploaded_at) as waktu_awal 
                FROM tb_berkas_pendaftaran 
                GROUP BY cpmi_id
            ) b_time ON p.cpmi_id = b_time.cpmi_id
            WHERE {$whereP} AND b_time.waktu_awal IS NOT NULL
            GROUP BY DATE(b_time.waktu_awal)
            ORDER BY tgl DESC 
            LIMIT 5
        ";
        $stmt =$pdo->prepare($sqlTrend);$stmt->execute($paramsP);$resTrend = $stmt->fetchAll(PDO::FETCH_ASSOC);$resTrend = array_reverse($resTrend); 
        $namaHari = ['Sunday' => 'Min', 'Monday' => 'Sen', 'Tuesday' => 'Sel', 'Wednesday' => 'Rab', 'Thursday' => 'Kam', 'Friday' => 'Jum', 'Saturday' => 'Sab'];
        
        foreach ($resTrend as$row) {
            $timestamp = strtotime($row['tgl']);
            $hariInggris = date('l',$timestamp);
            $hariIndo =$namaHari[$hariInggris];$tglFormat = date('d M', $timestamp);$trendTanggal[] = $hariIndo . ', ' .$tglFormat;
            $trendJumlah[] = (int)$row['jml'];
        }
    } catch (Throwable $e) {}

    try {
        $sqlDaerah = "
            SELECT COALESCE(NULLIF(TRIM(kabupaten), ''), NULLIF(TRIM(domisili), ''), 'Tidak Diketahui') AS daerah_clean, COUNT(*) AS total 
            FROM tb_pendaftaran p
            WHERE {$whereP} 
            GROUP BY COALESCE(NULLIF(TRIM(kabupaten), ''), NULLIF(TRIM(domisili), ''), 'Tidak Diketahui')
            ORDER BY total DESC LIMIT 5
        ";
        $stmt = $pdo->prepare($sqlDaerah);
        $stmt->execute($paramsP);
        while ($row =$stmt->fetch(PDO::FETCH_ASSOC)) {
            $labelDaerah[] = str_replace(['Kabupaten ', 'Kota '], '',$row['daerah_clean']);
            $dataDaerah[]  = (int)$row['total'];
        }
    } catch (Throwable $e) {}

    try {
        $sqlMinat = "
            SELECT TRIM(ref_pelatihan_dimin) AS nama_kategori, COUNT(*) AS total 
            FROM tb_pendaftaran p
            WHERE {$whereP} 
              AND ref_pelatihan_dimin IS NOT NULL 
              AND TRIM(ref_pelatihan_dimin) != ''
            GROUP BY TRIM(ref_pelatihan_dimin)
            ORDER BY total DESC LIMIT 5
        ";
        $stmt = $pdo->prepare($sqlMinat);
        $stmt->execute($paramsP);
        while ($row =$stmt->fetch(PDO::FETCH_ASSOC)) {
            $labelMinat[] =$row['nama_kategori'];
            $dataMinat[]  = (int)$row['total'];
        }
    } catch (Throwable $e) {}
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard PINTU | Pusat Informasi Pendaftaran Peningkatan Kapasitas CPMI</title>
    
    <link rel="icon" type="image/png" href="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/Logo_Kementerian_Pelindungan_Pekerja_Migran_Indonesia_-_BP2MI_v2_%282024%29.svg/960px-Logo_Kementerian_Pelindungan_Pekerja_Migran_Indonesia_-_BP2MI_v2_%282024%29.svg.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700;800&display=swap" rel="stylesheet">
    
    <style>
        body { 
            font-family: 'Nunito Sans', 'Plus Jakarta Sans', sans-serif; 
            background-color: #f4f6f9;
        }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        .sidebar-scroll::-webkit-scrollbar { width: 4px; }
        .sidebar-scroll::-webkit-scrollbar-track { background: transparent; }
        .sidebar-scroll::-webkit-scrollbar-thumb { background: rgba(14, 116, 187, 0.2); border-radius: 10px; }
        .sidebar-scroll::-webkit-scrollbar-thumb:hover { background: rgba(14, 116, 187, 0.4); }
    </style>
</head>
<body class="bg-[#f4f6f9] text-slate-800 min-h-screen md:h-screen flex flex-col md:flex-row overflow-x-hidden md:overflow-hidden selection:bg-[#0e74bb] selection:text-white">

    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <main class="flex-1 flex flex-col min-h-0 md:h-screen overflow-y-auto relative scroll-smooth bg-[#f4f6f9]">
        
        <div class="p-4 sm:p-7 max-w-7xl mx-auto w-full space-y-6">
            
            <div class="bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-xs relative overflow-hidden flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
                <div class="h-1 w-full bg-gradient-to-r from-[#0e74bb] via-[#1b88d4] to-[#074b7a] absolute top-0 left-0"></div>
                
                <div>
                    <div class="flex items-center gap-2 text-[11px] font-bold text-slate-400 mb-1.5">
                        <i class="fas fa-home text-[#0e74bb]"></i>
                        <span>/</span>
                        <span>Modul Pendaftaran</span>
                        <span>/</span>
                        <span class="text-slate-600">Dashboard PINTU</span>
                    </div>
                    <div class="flex items-center gap-2.5">
                        <div class="w-2.5 h-6 bg-[#0e74bb] rounded-full"></div>
                        <h2 class="text-xl sm:text-2xl font-black text-slate-900 tracking-tight uppercase">DASHBOARD PINTU</h2>
                    </div>
                    <p class="text-xs text-slate-500 mt-1 font-medium pl-5">Ringkasan Data Pendaftaran Program Peningkatan Kapasitas CPMI — BP3MI Jawa Tengah</p>
                </div>
                
                <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
                    <form method="GET" action="index.php" class="w-full sm:w-64">
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
                                <i class="fas fa-filter text-xs"></i>
                            </div>
                            <select name="batch" onchange="this.form.submit()" class="w-full text-xs font-bold bg-slate-50 hover:bg-slate-100/70 border border-slate-200 rounded-lg pl-9 pr-9 py-2.5 text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0e74bb]/20 focus:border-[#0e74bb] shadow-2xs appearance-none cursor-pointer transition">
                                <option value="all" <?= $selectedBatch === 'all' ? 'selected' : '' ?>>Semua Batch / Gelombang</option>
                                <?php foreach ($listBatch as $b): ?>
                                    <option value="<?= htmlspecialchars($b) ?>" <?= $selectedBatch === $b ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($b) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                                <i class="fas fa-chevron-down text-xs"></i>
                            </div>
                        </div>
                    </form>

                    <div class="inline-flex items-center gap-3 bg-slate-50 px-3.5 py-2 rounded-lg border border-slate-200 shadow-2xs shrink-0">
                        <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
                        <div class="text-right">
                            <div id="liveClock" class="text-xs sm:text-sm font-bold text-[#0e74bb] font-mono leading-none">--:--:-- WIB</div>
                            <div id="liveDate" class="text-[9px] font-bold text-slate-500 uppercase tracking-wider mt-0.5 leading-none">Memuat Tanggal...</div>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <div class="flex items-center gap-2 mb-3 px-0.5">
                    <div class="w-1.5 h-4 bg-[#0e74bb] rounded-full"></div>
                    <p class="text-xs font-bold uppercase tracking-wider text-slate-700">A. Data Pendaftaran & Kependudukan</p>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div class="bg-white p-5 rounded-xl border border-slate-200 border-l-4 border-l-[#0e74bb] shadow-xs flex flex-col justify-between hover:shadow-md hover:border-slate-300 transition-all duration-200">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Total Pendaftar</span>
                            <div class="w-9 h-9 rounded-lg bg-sky-50 text-[#0e74bb] border border-sky-100 flex items-center justify-center text-sm shadow-2xs">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                        <div>
                            <span class="text-2xl sm:text-3xl font-black text-slate-900 font-mono tracking-tight block"><?= number_format($totPendaftar, 0, ',', '.') ?></span>
                            <span class="text-[10px] font-semibold text-slate-400 mt-0.5 block">Akumulasi Pendaftaran</span>
                        </div>
                    </div>
                    
                    <div class="bg-white p-5 rounded-xl border border-slate-200 border-l-4 border-l-indigo-600 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-slate-300 transition-all duration-200">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Mayoritas Demografi</span>
                            <div class="w-9 h-9 rounded-lg bg-indigo-50 text-indigo-600 border border-indigo-100 flex items-center justify-center text-sm shadow-2xs">
                                <i class="fas fa-venus-mars"></i>
                            </div>
                        </div>
                        <div>
                            <span class="text-base sm:text-lg font-black text-slate-900 block truncate">
                                <?= htmlspecialchars($mayGender) ?>
                                <span class="text-slate-300 font-normal mx-1">|</span> 
                                <?= htmlspecialchars($mayUsia) ?><span class="text-xs font-bold text-slate-500"> Thn</span>
                            </span>
                            <span class="text-[10px] font-semibold text-slate-400 mt-0.5 block">Profil peserta terbanyak</span>
                        </div>
                    </div>

                    <div class="bg-white p-5 rounded-xl border border-slate-200 border-l-4 border-l-emerald-600 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-slate-300 transition-all duration-200">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status Verifikasi</span>
                            <div class="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-100 flex items-center justify-center text-sm shadow-2xs">
                                <i class="fas fa-clipboard-check"></i>
                            </div>
                        </div>
                        <div class="grid grid-cols-3 gap-1 pt-1 border-t border-slate-100 text-center">
                            <div>
                                <span class="block text-base font-black text-emerald-600 font-mono leading-none"><?= number_format($totVerifMS, 0, ',', '.') ?></span>
                                <span class="text-[8px] font-extrabold text-emerald-700 uppercase tracking-wider mt-1 block">MS</span>
                            </div>
                            <div class="border-x border-slate-100">
                                <span class="block text-base font-black text-rose-600 font-mono leading-none"><?= number_format($totVerifTMS, 0, ',', '.') ?></span>
                                <span class="text-[8px] font-extrabold text-rose-700 uppercase tracking-wider mt-1 block">TMS</span>
                            </div>
                            <div>
                                <span class="block text-base font-black text-slate-600 font-mono leading-none"><?= number_format($totVerifBelum, 0, ',', '.') ?></span>
                                <span class="text-[8px] font-extrabold text-slate-500 uppercase tracking-wider mt-1 block">Belum</span>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white p-5 rounded-xl border border-rose-200 border-l-4 border-l-rose-500 bg-rose-50/20 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-rose-300 transition-all duration-200">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-[10px] font-bold text-rose-700 uppercase tracking-widest">Indikasi NIK Ganda</span>
                            <div class="w-9 h-9 rounded-lg bg-rose-100 text-rose-600 border border-rose-200 flex items-center justify-center text-sm shadow-2xs">
                                <i class="fas fa-triangle-exclamation"></i>
                            </div>
                        </div>
                        <div>
                            <span class="text-2xl sm:text-3xl font-black text-rose-600 font-mono tracking-tight block">
                                <?= number_format($totNikGanda, 0, ',', '.') ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 gap-6">
                <div class="bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col">
                    <div class="flex items-center justify-between pb-3.5 mb-4 border-b border-slate-100">
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 rounded-lg bg-sky-50 text-[#0e74bb] flex items-center justify-center text-xs">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <div>
                                <h4 class="text-xs font-bold text-slate-800 uppercase tracking-wider">Trend Pendaftar Harian</h4>
                                <p class="text-[10px] text-slate-400 font-medium">Aktivitas Pendaftaran Peserta 5 hari Terakhir</p>
                            </div>
                        </div>
                        <span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-sky-50 text-[#0e74bb] border border-sky-100">5 Hari Terakhir</span>
                    </div>
                    <div class="h-64 sm:h-72 w-full relative flex-1">
                        <?php if (empty($trendTanggal)): ?>
                            <div class="absolute inset-0 flex items-center justify-center text-xs font-bold text-slate-400">Data trend pendaftaran belum tersedia.</div>
                        <?php else: ?>
                            <canvas id="trendChart"></canvas>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div>
                <div class="flex items-center gap-2 mb-3 px-0.5">
                    <div class="w-1.5 h-4 bg-amber-500 rounded-full"></div>
                    <p class="text-xs font-bold uppercase tracking-wider text-slate-700">B. Pelaksanaan & Rata-rata Nilai Ujian</p>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div class="bg-white p-5 rounded-xl border border-slate-200 border-l-4 border-l-[#0e74bb] shadow-xs flex flex-col justify-between hover:shadow-md hover:border-slate-300 transition-all duration-200">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Peserta Ujian Tertulis</span>
                            <div class="w-9 h-9 rounded-lg bg-sky-50 text-[#0e74bb] border border-sky-100 flex items-center justify-center text-sm shadow-2xs">
                                <i class="fas fa-file-signature"></i>
                            </div>
                        </div>
                        <div>
                            <span class="text-2xl sm:text-3xl font-black text-[#0e74bb] font-mono tracking-tight block"><?= number_format($pesertaTertulis, 0, ',', '.') ?></span>
                            <span class="text-[10px] font-semibold text-slate-400 mt-0.5 block">Selesai Mengerjakan</span>
                        </div>
                    </div>

                    <div class="bg-white p-5 rounded-xl border border-slate-200 border-l-4 border-l-sky-500 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-slate-300 transition-all duration-200">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Rata-rata Benar Tertulis</span>
                            <div class="w-9 h-9 rounded-lg bg-sky-50 text-sky-600 border border-sky-100 flex items-center justify-center text-sm shadow-2xs">
                                <i class="fas fa-check-double"></i>
                            </div>
                        </div>
                        <div>
                            <span class="text-2xl sm:text-3xl font-black text-sky-700 font-mono tracking-tight block"><?= number_format($avgTertulis, 1, ',', '.') ?></span>
                            <span class="text-[10px] font-semibold text-slate-400 mt-0.5 block">Jawaban Benar / Sesi</span>
                        </div>
                    </div>

                    <div class="bg-white p-5 rounded-xl border border-slate-200 border-l-4 border-l-amber-500 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-slate-300 transition-all duration-200">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Peserta Wawancara</span>
                            <div class="w-9 h-9 rounded-lg bg-amber-50 text-amber-600 border border-amber-100 flex items-center justify-center text-sm shadow-2xs">
                                <i class="fas fa-comments"></i>
                            </div>
                        </div>
                        <div>
                            <span class="text-2xl sm:text-3xl font-black text-amber-600 font-mono tracking-tight block"><?= number_format($pesertaInterview, 0, ',', '.') ?></span>
                            <span class="text-[10px] font-semibold text-slate-400 mt-0.5 block">Selesai Evaluasi</span>
                        </div>
                    </div>

                    <div class="bg-white p-5 rounded-xl border border-slate-200 border-l-4 border-l-orange-500 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-slate-300 transition-all duration-200">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Rata-rata Skor Interview</span>
                            <div class="w-9 h-9 rounded-lg bg-orange-50 text-orange-600 border border-orange-100 flex items-center justify-center text-sm shadow-2xs">
                                <i class="fas fa-star-half-stroke"></i>
                            </div>
                        </div>
                        <div>
                            <span class="text-2xl sm:text-3xl font-black text-orange-700 font-mono tracking-tight block"><?= number_format($avgInterview, 1, ',', '.') ?></span>
                            <span class="text-[10px] font-semibold text-slate-400 mt-0.5 block">Akumulasi Bobot Poin</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-xs relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-4">
                <div class="h-full w-1.5 bg-[#0e74bb] absolute left-0 top-0"></div>
                <div class="flex items-center gap-4 pl-2">
                    <div class="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#0e74bb] to-sky-400 text-white flex items-center justify-center text-lg shadow-xs shrink-0">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <div>
                        <span class="text-[10px] font-extrabold text-[#0e74bb] uppercase tracking-widest block mb-0.5">
                            Kategori Pelatihan Paling Diminati
                        </span>
                        <h3 class="text-base sm:text-xl font-black text-slate-900"><?= htmlspecialchars($pelatihanPopuler) ?></h3>
                    </div>
                </div>
                <div class="px-3.5 py-1.5 rounded-lg bg-sky-50 border border-sky-100 text-[11px] font-bold text-[#0e74bb] shrink-0">
                    <i class="fas fa-chart-pie mr-1"></i> Peminatan Tertinggi
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col">
                    <div class="flex items-center justify-between pb-3.5 mb-4 border-b border-slate-100">
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 rounded-lg bg-sky-50 text-[#0e74bb] flex items-center justify-center text-xs">
                                <i class="fas fa-building-columns"></i>
                            </div>
                            <div>
                                <h4 class="text-xs font-bold text-slate-800 uppercase tracking-wider">Top 5 Lembaga Pelatihan</h4>
                                <p class="text-[10px] text-slate-400 font-medium">Lembaga dengan pendaftar terbanyak</p>
                            </div>
                        </div>
                        <span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-600">Jenis Lembaga Pelatihan</span>
                    </div>
                    <?php if (empty($listTopLPK)): ?>
                        <div class="flex-1 flex items-center justify-center text-xs font-bold text-slate-400 py-8">Belum ada data lembaga.</div>
                    <?php else: ?>
                        <div class="space-y-2.5 flex-1 flex flex-col justify-center">
                            <?php foreach ($listTopLPK as $idx => $lpk): ?>
                                <div class="flex items-center justify-between p-3 bg-slate-50/70 hover:bg-sky-50/50 rounded-lg border border-slate-200/60 transition group">
                                    <div class="flex items-center gap-3 min-w-0">
                                        <span class="flex items-center justify-center min-w-[26px] h-6.5 rounded-md <?= $idx === 0 ? 'bg-[#0e74bb] text-white' : ($idx === 1 ? 'bg-sky-200 text-[#0e74bb]' : 'bg-slate-200 text-slate-700') ?> font-extrabold text-[11px] shadow-2xs">
                                            <?= $idx + 1 ?>
                                        </span>
                                        <span class="font-bold text-slate-700 text-xs truncate group-hover:text-[#0e74bb] transition-colors"><?= htmlspecialchars($lpk['nama_lembaga']) ?></span>
                                    </div>
                                    <span class="font-black text-[#0e74bb] font-mono text-xs sm:text-sm ml-3 shrink-0"><?= number_format($lpk['total'], 0, ',', '.') ?> <span class="text-[10px] font-semibold text-slate-400 font-sans">CPMI</span></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col">
                    <div class="flex items-center justify-between pb-3.5 mb-4 border-b border-slate-100">
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 rounded-lg bg-sky-50 text-[#0e74bb] flex items-center justify-center text-xs">
                                <i class="fas fa-chart-pie"></i>
                            </div>
                            <div>
                                <h4 class="text-xs font-bold text-slate-800 uppercase tracking-wider">Top 5 Jenis Pelatihan</h4>
                                <p class="text-[10px] text-slate-400 font-medium">Distribusi Peminatan Pelatihan</p>
                            </div>
                        </div>
                        <span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-600">Jenis Pelatihan</span>
                    </div>
                    <div class="h-64 w-full flex justify-center relative flex-1">
                        <?php if (empty($labelMinat)): ?>
                            <div class="absolute inset-0 flex items-center justify-center text-xs font-bold text-slate-400">Belum ada data pendaftar</div>
                        <?php else: ?>
                            <canvas id="pieChart"></canvas>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="grid grid-cols-1 gap-6 pb-8">
                <div class="bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col">
                    <div class="flex items-center justify-between pb-3.5 mb-4 border-b border-slate-100">
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 rounded-lg bg-sky-50 text-[#0e74bb] flex items-center justify-center text-xs">
                                <i class="fas fa-map-location-dot"></i>
                            </div>
                            <div>
                                <h4 class="text-xs font-bold text-slate-800 uppercase tracking-wider">Top 5 Asal Daerah Peserta</h4>
                                <p class="text-[10px] text-slate-400 font-medium">Kabupaten/Kota domisili terbanyak</p>
                            </div>
                        </div>
                        <span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-600">Sebaran Daerah</span>
                    </div>
                    <div class="h-64 sm:h-72 w-full relative flex-1">
                        <?php if (empty($labelDaerah)): ?>
                            <div class="absolute inset-0 flex items-center justify-center text-xs font-bold text-slate-400">Belum ada data pendaftar</div>
                        <?php else: ?>
                            <canvas id="barChart"></canvas>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
        </div>
    </main>
    
    <script>
        function updateClock() {
            const now = new Date();
            const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
            const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
            
            let hh = now.getHours().toString().padStart(2, '0');
            let mm = now.getMinutes().toString().padStart(2, '0');
            let ss = now.getSeconds().toString().padStart(2, '0');
            document.getElementById('liveClock').textContent = `${hh}:${mm}:${ss} WIB`;
            document.getElementById('liveDate').textContent = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
        }
        setInterval(updateClock, 1000); 
        updateClock();

        const labelDaerah = <?= json_encode($labelDaerah) ?>;
        const dataDaerah  = <?= json_encode($dataDaerah) ?>;
        const labelMinat  = <?= json_encode($labelMinat) ?>;
        const dataMinat   = <?= json_encode($dataMinat) ?>;
        
        const labelTrend  = <?= json_encode($trendTanggal) ?>;
        const dataTrend   = <?= json_encode($trendJumlah) ?>;

        if (labelTrend.length > 0) {
            new Chart(document.getElementById('trendChart'), {
                type: 'bar',
                data: {
                    labels: labelTrend,
                    datasets: [{
                        label: 'Pendaftar Baru',
                        data: dataTrend,
                        backgroundColor: '#0e74bb',
                        hoverBackgroundColor: '#0b5e99',
                        borderRadius: 6,
                        maxBarThickness: 46
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            titleFont: { family: "'Plus Jakarta Sans', sans-serif", size: 12 },
                            bodyFont: { family: "'Plus Jakarta Sans', sans-serif", size: 12, weight: 'bold' }
                        }
                    },
                    scales: {
                        x: {
                            grid: { display: false },
                            ticks: { font: { size: 11, family: "'Plus Jakarta Sans', sans-serif", weight: 'bold' }, color: '#64748b' }
                        },
                        y: {
                            beginAtZero: true,
                            grid: { color: '#e2e8f0', drawBorder: false },
                            ticks: { font: { size: 11, family: "'Plus Jakarta Sans', sans-serif" }, stepSize: 1, color: '#64748b' }
                        }
                    }
                }
            });
        }

        if (labelDaerah.length > 0) {
            new Chart(document.getElementById('barChart'), {
                type: 'bar',
                data: {
                    labels: labelDaerah,
                    datasets: [{
                        label: 'Pendaftar',
                        data: dataDaerah,
                        backgroundColor: '#0e74bb',
                        hoverBackgroundColor: '#0b5e99',
                        borderRadius: 6,
                        barPercentage: 0.55
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true, 
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { display: true, color: '#e2e8f0' }, ticks: { color: '#64748b' } },
                        y: { grid: { display: false }, ticks: { font: { size: 11, family: "'Plus Jakarta Sans', sans-serif", weight: 'bold' }, color: '#334155' } }
                    }
                }
            });
        }

        if (labelMinat.length > 0) {
            new Chart(document.getElementById('pieChart'), {
                type: 'doughnut',
                data: {
                    labels: labelMinat,
                    datasets: [{
                        data: dataMinat,
                        backgroundColor: ['#0e74bb', '#0284c7', '#10b981', '#f59e0b', '#8b5cf6', '#64748b'],
                        borderWidth: 2, 
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true, 
                    maintainAspectRatio: false, 
                    cutout: '65%',
                    plugins: {
                        legend: { 
                            position: 'right', 
                            labels: { boxWidth: 12, font: { size: 10, family: "'Plus Jakarta Sans', sans-serif", weight: '600' }, color: '#475569' } 
                        }
                    }
                }
            });
        }
    </script>
</body>
</html>