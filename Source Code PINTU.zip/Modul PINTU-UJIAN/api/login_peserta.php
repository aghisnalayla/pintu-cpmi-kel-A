<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once 'koneksi.php';
require_once 'rate_limiter.php';

try {
    // 1. Cek batas percobaan login
    checkRateLimit($pdo, 'peserta', 5, 10);

    $inputJSON = file_get_contents('php://input');
    $payload = json_decode($inputJSON, true);

    $nik = trim($payload['nik'] ?? '');
    $tanggal_lahir = trim($payload['tanggal_lahir'] ?? '');

    if (empty($nik) || empty($tanggal_lahir)) {
        echo json_encode(['status' => 'error', 'message' => 'NIK dan Tanggal Lahir wajib diisi.']);
        exit;
    }

    $sql = "
        SELECT 
            p.*,
            pu.id AS peserta_ujian_id,
            pu.jenis_ujian,
            pu.status_pengerjaan,
            pu.jadwal_mulai,
            pu.jadwal_selesai
        FROM tb_peserta_ujian pu
        INNER JOIN tb_pendaftaran p 
            ON pu.cpmi_id = p.cpmi_id
        INNER JOIN tb_status_verifikasi sv 
            ON p.cpmi_id = sv.cpmi_id 
            AND UPPER(TRIM(sv.status)) = 'MEMENUHI PERSYARATAN'
        WHERE p.nik_sesuai_ktp = :nik 
          AND p.tanggal_lahir = :tanggal_lahir
        ORDER BY pu.id DESC
        LIMIT 1
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['nik' => $nik, 'tanggal_lahir' => $tanggal_lahir]);
    $peserta = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$peserta) {
        recordFailedAttempt($pdo, 'peserta');

        $stmtCek = $pdo->prepare("
            SELECT sv.status 
            FROM tb_pendaftaran p
            LEFT JOIN tb_status_verifikasi sv ON p.cpmi_id = sv.cpmi_id
            WHERE p.nik_sesuai_ktp = :nik AND p.tanggal_lahir = :tanggal_lahir
            ORDER BY (UPPER(TRIM(sv.status)) = 'MEMENUHI PERSYARATAN') DESC
            LIMIT 1
        ");
        $stmtCek->execute(['nik' => $nik, 'tanggal_lahir' => $tanggal_lahir]);
        $cekData = $stmtCek->fetch(PDO::FETCH_ASSOC);

        if ($cekData) {
            $statCek = strtoupper(trim((string)$cekData['status']));
            if ($statCek === 'TIDAK MEMENUHI PERSYARATAN') {
                $pesan = 'Status berkas pendaftaran Anda: Tidak Memenuhi Persyaratan (TMS).';
            } elseif ($statCek === 'MEMENUHI PERSYARATAN') {
                $pesan = 'Berkas Anda Memenuhi Persyaratan, namun belum dijadwalkan sesi ujian oleh Administrator.';
            } else {
                $pesan = 'Berkas pendaftaran Anda masih dalam tahap verifikasi.';
            }
        } else {
            $pesan = 'Data peserta tidak ditemukan. Pastikan NIK dan Tanggal Lahir sudah sesuai.';
        }

        echo json_encode(['status' => 'error', 'message' => $pesan]);
        exit;
    }

    if ((isset($peserta['status_pengerjaan']) && strtoupper($peserta['status_pengerjaan']) === 'SELESAI') || 
        (isset($peserta['status_ujian']) && strtolower($peserta['status_ujian']) === 'selesai')) {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak! Anda sudah menyelesaikan ujian ini sebelumnya.']);
        exit;
    }

    clearFailedAttempts($pdo, 'peserta');
    $_SESSION['cpmi_id']      = $peserta['cpmi_id'];
    $_SESSION['nama_lengkap'] = $peserta['nama_lengkap'];
    $_SESSION['jenis_ujian']  = $peserta['jenis_ujian'];

    echo json_encode([
        'status'   => 'success',
        'message'  => 'Verifikasi identitas berhasil.',
        'redirect' => 'dashboard.php',
        'peserta'  => [
            'nama_lengkap'      => $peserta['nama_lengkap'] ?? '',
            'nik_sesuai_ktp'    => $peserta['nik_sesuai_ktp'] ?? '',
            'cpmi_id'           => $peserta['cpmi_id'] ?? '',
            'jenis_ujian'       => $peserta['jenis_ujian'] ?? '',
            'alamat_domisili'   => $peserta['alamat_domisili'] ?? '-',
            'batch_pelatihan'   => $peserta['batch_pelatihan'] ?? '-',
            'lembaga_pelatihan' => $peserta['lembaga_pelatihan'] ?? '-'
        ]
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Kesalahan server: ' . $e->getMessage()]);
}