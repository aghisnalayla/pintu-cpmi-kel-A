<?php

function getClientIP() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ipList[0]);
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function checkRateLimit($pdo, $type, $maxAttempts = 5, $decayMinutes = 10) {
    $ip = getClientIP();
    $decayMinutes = (int)$decayMinutes;

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM tb_login_attempts 
            WHERE ip_address = :ip 
              AND attempt_type = :type 
              AND attempt_time > (NOW() - INTERVAL {$decayMinutes} MINUTE)
        ");
        $stmt->execute([
            'ip'   => $ip,
            'type' => $type
        ]);
        
        $attempts = $stmt->fetchColumn();

        if ($attempts >= $maxAttempts) {
            http_response_code(429);
            echo json_encode([
                'status'  => 'error',
                'message' => "Terlalu banyak percobaan gagal dari perangkat Anda. Silakan tunggu {$decayMinutes} menit."
            ]);
            exit;
        }
    } catch (Throwable $e) {
        error_log("Rate limiter error: " . $e->getMessage());
    }
}

function recordFailedAttempt($pdo, $type) {
    $ip = getClientIP();
    try {
        $stmt = $pdo->prepare("INSERT INTO tb_login_attempts (ip_address, attempt_type) VALUES (:ip, :type)");
        $stmt->execute(['ip' => $ip, 'type' => $type]);
        sleep(1); 
    } catch (Throwable $e) {
        error_log("Record attempt error: " . $e->getMessage());
    }
}

function clearFailedAttempts($pdo, $type) {
    $ip = getClientIP();
    try {
        $stmt = $pdo->prepare("DELETE FROM tb_login_attempts WHERE ip_address = :ip AND attempt_type = :type");
        $stmt->execute(['ip' => $ip, 'type' => $type]);
    } catch (Throwable $e) {
        error_log("Clear attempt error: " . $e->getMessage());
    }
}