<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/koneksi.php';

try {
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);

    $cpmi_id = trim($data['cpmi_id'] ?? ($_SESSION['cpmi_id'] ?? ''));
    $soal_id = (int)($data['soal_id'] ?? 0);
    $jawaban = strtoupper(trim($data['jawaban_pilihan'] ?? ''));

    if (empty($cpmi_id) || empty($soal_id) || empty($jawaban)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Parameter tidak lengkap.']);
        exit;
    }

    $stmtCekUser = $pdo->prepare("SELECT cpmi_id FROM tb_pendaftaran WHERE cpmi_id = :cpmi_id LIMIT 1");
    $stmtCekUser->execute(['cpmi_id' => $cpmi_id]);
    if (!$stmtCekUser->fetch()) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Peserta tidak sah.']);
        exit;
    }

    if (!isset($_SESSION['cpmi_id'])) {
        $_SESSION['cpmi_id'] = $cpmi_id;
    }

    $cekStmt = $pdo->prepare("SELECT id FROM tb_jawaban_peserta WHERE cpmi_id = :cpmi_id AND soal_id = :soal_id LIMIT 1");
    $cekStmt->execute(['cpmi_id' => $cpmi_id, 'soal_id' => $soal_id]);
    $ada = $cekStmt->fetch(PDO::FETCH_ASSOC);

    if ($ada) {
        $updateStmt = $pdo->prepare("UPDATE tb_jawaban_peserta SET jawaban_pilihan = :jwb, updated_at = NOW() WHERE id = :id");
        $updateStmt->execute(['jwb' => $jawaban, 'id' => $ada['id']]);
    } else {
        $insertStmt = $pdo->prepare("INSERT INTO tb_jawaban_peserta (cpmi_id, soal_id, jawaban_pilihan, updated_at) VALUES (:cpmi_id, :soal_id, :jwb, NOW())");
        $insertStmt->execute(['cpmi_id' => $cpmi_id, 'soal_id' => $soal_id, 'jwb' => $jawaban]);
    }

    echo json_encode(['status' => 'success', 'message' => 'Tersimpan ke database']);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}